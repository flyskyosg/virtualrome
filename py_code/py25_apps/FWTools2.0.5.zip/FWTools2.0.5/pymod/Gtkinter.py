
#This is for compatibility.

print "importing Gtkinter is deprecated -- use 'from gtk import *'"

from gtk import *
from gtk import _name2cls,_obj2inst

